﻿define(["angular", "angularAMD", "angular-ui-router"], function (ng, angularAMD) {
    var app = angular.module("app", ["ui.router"]);
    return angularAMD.bootstrap(app);
});