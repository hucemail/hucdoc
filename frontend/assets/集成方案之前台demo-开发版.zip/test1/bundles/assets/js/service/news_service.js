﻿/*为新闻提供数据的服务*/
define(["app"], function (app) {
    require("api_service");
    app.factory("NewsService", ["$http", "APIService", function ($http, APIService) {
        return {
            getNewsCategory: function (params, before) {
                if (typeof before === "function") {
                    before();
                }
                return $http({
                    method: "get",
                    url: APIService.newscategory,
                    cache:true, //不经常变动的数据可以开启缓存,节省后台的多余请求
                    params: params
                });
            },
            getNews: function (params, before) {
                if (typeof before === "function") {
                    before();
                }
                return $http({
                    method: "get",
                    url: APIService.news,
                    params: params
                });
            }
        };
    }]);
});
