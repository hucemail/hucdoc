﻿/*接口服务：管理所有接口地址*/
define(["app"], function (app) {
    return app.constant("APIService", {
        news: "../../../../json/news.json",
        newscategory: "../../../../json/newscategory.json"
    });
});
