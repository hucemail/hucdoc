﻿define(["app"], function (app) {
    require("../service/news_service");
    return app.controller("newListCtrl", ["$scope", "$state", "$stateParams", "$timeout", "NewsService", function ($scope, $state, $stateParams, $timeout, NewsService) {

        $scope.$watch('$viewContentLoading', function (event, viewConfig) {
            $scope.curid = $stateParams.categoryid;
            //查询新闻类别
            NewsService.getNewsCategory().then(function (res) {
                $scope.categorys = res.data;
                if ($scope.curid == null) {
                    $scope.curid = $scope.categorys[0].id;
                }
            });
            $timeout(function () {
                //查询新闻
                NewsService.getNews({ categoryid: $stateParams.categoryid }).then(function (res) {
                    $scope.news = res.data;
                });
            }, 2000);
        });

        $scope.$watch('$viewContentLoaded', function (event) {

        });
    }]);
});
