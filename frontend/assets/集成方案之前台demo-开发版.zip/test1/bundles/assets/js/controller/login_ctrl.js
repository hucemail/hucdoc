﻿define(["app"], function (app) {
    return app.controller("loginCtrl", ["$scope", "$state", "initData", function ($scope, $state, initData) {
        $scope.form = initData;
        $scope.$watch('$viewContentLoading', function (event, viewConfig) {
            alert('模板加载完成前');
        });
        $scope.$watch('$viewContentLoaded', function (event) {
            alert('模板加载完成后');
        });
        $scope.login = function () {
            //登录逻辑,登录成功跳转到首页
            $state.go("/");
        };
    }]);
});
