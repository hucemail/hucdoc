﻿define(["app"], function (app) {
    require("../controller/newlist_ctrl");
    return app.config(["$stateProvider", function ($stateProvider) {
        $stateProvider.state("news", {
            url: "/news/{categoryid}",
            params: {
                categoryid:null
            },
            views: {
                "header": {
                    templateUrl: "../../../../view/header.html"
                },
                "footer": {
                    templateUrl: "../../../../view/footer.html"
                },
                "container": {
                    templateUrl: "../../../../view/news/index.html",
                    controller: "newListCtrl"
                }
            }
        });
    }]);
});
