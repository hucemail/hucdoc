﻿define([], function () {
    require("router_config");
    require("root_router");
    require("news_router");
    require("login_router");
    require("register_router");
});
//ui-router知识参考:http://www.cnblogs.com/hualuna87/p/6045310.html