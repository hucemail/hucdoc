﻿define(["app"], function (app) {
    return app.config(["$stateProvider", function ($stateProvider) {
        $stateProvider.state("/", {
            url: "/",
            views: {
                "header": {
                    templateUrl: "../../../../view/header.html"
                },
                "footer": {
                    templateUrl: "../../../../view/footer.html"
                },
                "container": {
                    templateUrl: "../../../../view/index.html"
                }
            }
        });
    }]);
});
