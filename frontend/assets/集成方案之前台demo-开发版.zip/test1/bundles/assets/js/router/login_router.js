﻿define(["app"], function (app) {
    require("../controller/login_ctrl");
    return app.config(["$stateProvider", function ($stateProvider) {
        $stateProvider.state("login", {
            url: "/login",
            templateUrl: "../../../../view/login.html",
            //预载入
            resolve:{
                initData: function () {
                    return { account: "hucemail", password: "12345678" }
                }
            },
            controller:"loginCtrl"
        });
    }]);
});
