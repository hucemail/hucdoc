﻿define(["app"], function (app) {
    return app.config(["$urlRouterProvider", "$locationProvider", function ($urlRouterProvider, $locationProvider) {
        //使用html5路由，IIS服务器配置请查看webconfig。
        //其他服务器配置参考：http://blog.csdn.net/Vin1992/article/details/72819751
        $locationProvider.html5Mode({
            enabled: true,
            requireBase: false
        });
        //解决高版本ng路由出现#！的问题
        $locationProvider.hashPrefix("");
        //路由配置表
        $urlRouterProvider.otherwise("/");
    }]);
});
