﻿define(["app"], function (app) {
    return app.config(["$stateProvider", function ($stateProvider) {
        $stateProvider.state("register", {
            url: "/register",
            templateUrl: "../../../../view/register.html"
        });
    }]);
});
