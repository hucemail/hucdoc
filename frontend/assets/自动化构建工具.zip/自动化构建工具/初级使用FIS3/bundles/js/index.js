﻿window.onload = function () {
    document.getElementById("btn").onclick = function () {
        customer_alert("首页.");
    };
}