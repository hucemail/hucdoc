﻿function customer_alert(value) {
    alert(value);
}