﻿define([], function () {
    console.log("math");
    return {
        init: function () {
            console.log("math-init");
        }
    }
});

