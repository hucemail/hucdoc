﻿requirejs.config({
    baseUrl:"bundles/js",
    paths: {
        "jquery": "jquery-3.2.1.min"
    }
});
