﻿define(["jquery"], function ($) {
    $(".site-nav-icon").click(function () {
        alert($(this).text());
    });
});