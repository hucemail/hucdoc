﻿var math = require('./math');

alert(math.add(2, 3));