﻿var number = 123;

var math = {
    add: function (a, b) {
        return a + b;
    },
    sub: function (a, b) {
        return a - b;
    }
};

exports.math=math;