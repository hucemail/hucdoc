﻿define(function (require, exports, module) {
    require("common/neatness.validate");
    $("body").css({ "background-color": "red" });
})


