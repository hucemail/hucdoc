﻿requirejs.config({
    baseUrl:"js",
    paths: {
        "jquery": ["https://cdn.bootcss.com/jquery/3.2.1/jquery.min"],
        "mymodel":"my"
    }
});